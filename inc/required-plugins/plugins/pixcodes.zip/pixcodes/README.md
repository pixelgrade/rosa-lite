=== PixCodes ===

WordPress shortcodes plugin. Loaded with shortcodes, awesomeness and more.

=== # ===

~Current Version:2.3.0~

=== # ===

Tags: wordpress, shortcodes, plugin
Requires at least: 3.5.1
Tested up to: 4.0.1
Stable tag: 4.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

=== # ===