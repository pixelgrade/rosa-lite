=== PixTypes ===

WordPress plugin for managing custom post types and custom meta boxes.

=== # ===

~Current Version:1.2.1~
Dev note: use debug=true in url for some debugging

=== # ===

Tags: wordpress, cpt, metaboxes, custom post types, plugin
Requires at least: 3.5.1
Tested up to: 3.8.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

=== # ===

=== Changelog  ===

1.2.1

Github Updater slug fix
And small fixes...

1.2.0

Ajax Update
Gallery Metabox works now even if there is no wp-editor on page
And small fixes...

1.1.0

Add admin panel
Fixes

1.0.0 - Here we go
